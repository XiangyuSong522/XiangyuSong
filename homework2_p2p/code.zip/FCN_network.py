import torch
import torch.nn as nn

class FullyConvNetwork(nn.Module):

    def __init__(self):
        super(FullyConvNetwork, self).__init__()
        # Encoder (Convolutional Layers)
        self.conv1 = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, stride=1, padding=1),  # Reduced channels
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1),  # Reduced channels
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )

        self.conv3 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),  # Reduced channels
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )

        # Decoder (Upsample Layers)
        self.upscore1 = nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1, output_padding=0, bias=False)
        self.upscore2 = nn.ConvTranspose2d(64, 32, kernel_size=4, stride=2, padding=1, output_padding=0, bias=False)
        self.upscore3 = nn.ConvTranspose2d(32, 3, kernel_size=4, stride=2, padding=1, output_padding=0, bias=False)

        # Final Output Activation (using tanh for [0,1] range)
        self.tanh = nn.Tanh()

    def forward(self, x):
        # Encoder forward pass
        conv1_out = self.conv1(x)
        conv2_out = self.conv2(conv1_out)
        conv3_out = self.conv3(conv2_out)

        # Decoder with skip connections
        upscore1_out = self.upscore1(conv3_out)
        upscore1_out = upscore1_out + conv2_out  # Skip connection from conv2 to upscore1

        upscore2_out = self.upscore2(upscore1_out)
        upscore2_out = upscore2_out + conv1_out  # Skip connection from conv1 to upscore2

        upscore3_out = self.upscore3(upscore2_out)

        # Final output activation (scaled to [0, 1] using tanh)
        output = self.tanh(upscore3_out)

        return output