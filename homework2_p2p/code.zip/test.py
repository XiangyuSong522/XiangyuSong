import torch
import torch.nn as nn

class FullyConvNetwork(nn.Module):

    def __init__(self):
        super(FullyConvNetwork, self).__init__()
        # Encoder (Convolutional Layers)
        self.conv1 = nn.Sequential(
            nn.Conv2d(3, 32, kernel_size=3, stride=1, padding=1),  # Reduced channels
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(32, 32, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)

        self.conv3 = nn.Sequential(
            nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)

        self.conv4 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.pool3 = nn.MaxPool2d(kernel_size=2, stride=2)

        # Decoder (Upsample Layers)
        self.fc6 = nn.Sequential(
            nn.Conv2d(128, 512, kernel_size=3, stride=1, padding=1),  # Reduced size
            nn.ReLU(inplace=True)
        )
        self.drop6 = nn.Dropout(0.5)

        self.fc7 = nn.Sequential(
            nn.Conv2d(512, 128, kernel_size=1, stride=1, padding=0),  # Reduced size
            nn.ReLU(inplace=True)
        )
        self.drop7 = nn.Dropout(0.5)

        # Final Score and Upsampling
        self.score_fr = nn.Conv2d(128, 64, kernel_size=1, stride=1, padding=0)

        # Upsample using Transposed Convolution (Deconvolution)
        self.upscore1 = nn.ConvTranspose2d(64, 32, kernel_size=4, stride=2, padding=1, output_padding=0, bias=False)  # Reduced kernel size
        self.upscore2 = nn.ConvTranspose2d(32, 16, kernel_size=4, stride=2, padding=1, output_padding=0, bias=False)  # Reduced kernel size
        self.upscore3 = nn.ConvTranspose2d(16, 3, kernel_size=4, stride=2, padding=1, output_padding=0, bias=False)  # Reduced kernel size
        self.tanh = nn.Tanh()  # Output RGB image with values in [-1, 1]

    def forward(self, x):
        # Forward pass through encoder
        x = self.conv1(x)
        x = self.conv2(x)
        # x = self.pool1(x)

        x = self.conv3(x)
        # x = self.pool2(x)

        x = self.conv4(x)
        # x = self.pool3(x)

        # Forward pass through decoder
        x = self.fc6(x)
        x = self.drop6(x)

        x = self.fc7(x)
        x = self.drop7(x)

        # Final score layer
        x = self.score_fr(x)

        # Upsampling
        x = self.upscore1(x)
        x = self.upscore2(x)
        x = self.upscore3(x)

        return self.tanh(x)

















import torch
import torch.nn as nn

class FullyConvNetwork(nn.Module):

    def __init__(self):
        super(FullyConvNetwork, self).__init__()
        # Encoder (Convolutional Layers)
        self.conv1 = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1),  # Increased channels
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )

        self.conv3 = nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(256),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )

        self.conv4 = nn.Sequential(
            nn.Conv2d(256, 512, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm2d(512),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=2, stride=2)
        )

        # Decoder (Upsample Layers)
        self.upscore1 = nn.ConvTranspose2d(512, 256, kernel_size=4, stride=2, padding=1, output_padding=0, bias=False)
        self.upscore2 = nn.ConvTranspose2d(256, 128, kernel_size=4, stride=2, padding=1, output_padding=0, bias=False)
        self.upscore3 = nn.ConvTranspose2d(128, 64, kernel_size=4, stride=2, padding=1, output_padding=0, bias=False)
        self.upscore4 = nn.ConvTranspose2d(64, 3, kernel_size=4, stride=2, padding=1, output_padding=0, bias=False)

        # Final Output Activation (using tanh for [0,1] range)
        self.tanh = nn.Tanh()

    def forward(self, x):
        # Encoder forward pass
        conv1_out = self.conv1(x)
        conv2_out = self.conv2(conv1_out)
        conv3_out = self.conv3(conv2_out)
        conv4_out = self.conv4(conv3_out)

        # Decoder with skip connections
        upscore1_out = self.upscore1(conv4_out)
        upscore1_out = upscore1_out + conv3_out  # Skip connection from conv3 to upscore1

        upscore2_out = self.upscore2(upscore1_out)
        upscore2_out = upscore2_out + conv2_out  # Skip connection from conv2 to upscore2

        upscore3_out = self.upscore3(upscore2_out)
        upscore3_out = upscore3_out + conv1_out  # Skip connection from conv1 to upscore3

        upscore4_out = self.upscore4(upscore3_out)

        # Final output activation (scaled to [0, 1] using tanh)
        output = self.tanh(upscore4_out)

        return output
